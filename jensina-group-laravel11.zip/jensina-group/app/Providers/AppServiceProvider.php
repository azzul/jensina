<?php

namespace App\Providers;

use App\View\Composers\SiteDataComposer;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Shares $siteSettings / $currentLocale / $otherLocale / $alternateLocaleUrl
        // with layouts.app on every request, so every controller stays free
        // of boilerplate "pass the settings to the view" code.
        View::composer('layouts.app', SiteDataComposer::class);
    }
}
